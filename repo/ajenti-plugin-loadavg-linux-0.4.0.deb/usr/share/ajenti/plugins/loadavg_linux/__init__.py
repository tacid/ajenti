from ajenti.app.plugins import require
require('loadavg')

from main import *
