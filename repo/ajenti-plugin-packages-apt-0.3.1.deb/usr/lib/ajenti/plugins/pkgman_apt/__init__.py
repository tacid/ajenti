from ajenti.app.plugins import require
require('pkgman')

from main import *
