version = 'alpha (GIT snapshot)'
