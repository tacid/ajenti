from ajenti.app.plugins import require
require('squid')

from ui_sarg import *
